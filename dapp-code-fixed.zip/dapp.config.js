const RPC_URL = process.env.NEXT_PUBLIC_ALCHEMY_RPC_URL

const config = {
  title: 'Dapp',
  description: 'minting Dapp',
  contractAddress: '0x9FA18D14b84B07fF08c049ebECcdC939FB85FBe7',
  tokenContractAddress: '0x69845B882Ec371fe8f851914eA0756C939CD4F8A'
}

export { config }
