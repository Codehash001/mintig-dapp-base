module.exports = [
    
    'address1',
    'address2'
  ]